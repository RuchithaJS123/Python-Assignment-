import tkinter as tk
from tkinter import messagebox
import sqlite3

# Database setup
conn = sqlite3.connect("todo.db")
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, task TEXT)")
conn.commit()

# Functions
def add_task():
    task = task_entry.get()
    if task:
        cursor.execute("INSERT INTO tasks (task) VALUES (?)", (task,))
        conn.commit()
        list_tasks()
        task_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Warning", "Task cannot be empty!")

def delete_task():
    try:
        selected_task = task_listbox.get(task_listbox.curselection())
        cursor.execute("DELETE FROM tasks WHERE task=?", (selected_task,))
        conn.commit()
        list_tasks()
    except:
        messagebox.showwarning("Warning", "Please select a task to delete!")

def list_tasks():
    task_listbox.delete(0, tk.END)
    cursor.execute("SELECT task FROM tasks")
    for row in cursor.fetchall():
        task_listbox.insert(tk.END, row[0])

# GUI setup
root = tk.Tk()
root.title("To-Do List App")

frame = tk.Frame(root)
frame.pack(pady=10)

task_entry = tk.Entry(frame, width=40)
task_entry.pack(side=tk.LEFT, padx=5)

add_button = tk.Button(frame, text="Add Task", command=add_task)
add_button.pack(side=tk.LEFT)

task_listbox = tk.Listbox(root, width=50, height=10)
task_listbox.pack(pady=10)

delete_button = tk.Button(root, text="Delete Task", command=delete_task)
delete_button.pack()

list_tasks()

root.mainloop()

# Close database connection on exit
conn.close()
