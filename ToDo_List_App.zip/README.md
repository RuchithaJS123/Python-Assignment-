# To-Do List App

A simple to-do list application built using Python and Tkinter with SQLite database support.

## Features
- Add tasks to the list.
- Delete tasks from the list.
- Data persistence using SQLite.

## Requirements
- Python 3.x
- Tkinter (built-in)
- SQLite (built-in)

## How to Run
```bash
python main.py
```
